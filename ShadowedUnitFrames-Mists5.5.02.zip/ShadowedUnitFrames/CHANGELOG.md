# Shadowed Unit Frames

## [v4.4.11-3-g77bd580](https://github.com/Nevcairiel/ShadowedUnitFrames/tree/77bd580c9a58ab07f38eab6bc0368f2c0d8e92c6) (2024-10-16)
[Full Changelog](https://github.com/Nevcairiel/ShadowedUnitFrames/compare/v4.4.11...77bd580c9a58ab07f38eab6bc0368f2c0d8e92c6) [Previous Releases](https://github.com/Nevcairiel/ShadowedUnitFrames/releases)

- Update TOC for future releases  
- Specify ubuntu-22.04 as the running image, as latest lacks subversion  
- Add support for BigWigs Spell Renames  
